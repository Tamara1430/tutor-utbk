'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import {
  Calendar,
  Clock,
  Trophy,
  TrendingUp,
  FileText,
  Filter,
  Download,
  Eye,
  BarChart3
} from 'lucide-react'
import { Button } from '@/components/ui/button'

export default function ExamHistory() {
  const [selectedFilter, setSelectedFilter] = useState('all')

  // Data dummy untuk histori ujian
  const examHistory = [
    {
      id: 1,
      title: 'Tryout UTBK Matematika Saintek',
      date: '2024-01-15',
      score: 88,
      maxScore: 100,
      duration: '120 menit',
      questions: 40,
      correctAnswers: 35,
      category: 'matematika',
      difficulty: 'Sulit',
      rank: 125,
      totalParticipants: 1250,
      status: 'completed'
    },
    {
      id: 2,
      title: 'Tryout Bahasa Indonesia UTBK',
      date: '2024-01-12',
      score: 92,
      maxScore: 100,
      duration: '90 menit',
      questions: 30,
      correctAnswers: 28,
      category: 'bahasa',
      difficulty: 'Sedang',
      rank: 45,
      totalParticipants: 980,
      status: 'completed'
    },
    {
      id: 3,
      title: 'Tryout Fisika Dasar',
      date: '2024-01-10',
      score: 76,
      maxScore: 100,
      duration: '100 menit',
      questions: 35,
      correctAnswers: 27,
      category: 'fisika',
      difficulty: 'Mudah',
      rank: 280,
      totalParticipants: 750,
      status: 'completed'
    },
    {
      id: 4,
      title: 'Tryout Kimia Organik',
      date: '2024-01-08',
      score: 85,
      maxScore: 100,
      duration: '110 menit',
      questions: 38,
      correctAnswers: 32,
      category: 'kimia',
      difficulty: 'Sulit',
      rank: 98,
      totalParticipants: 620,
      status: 'completed'
    }
  ]

  const filters = [
    { id: 'all', name: 'Semua', count: examHistory.length },
    { id: 'matematika', name: 'Matematika', count: examHistory.filter(e => e.category === 'matematika').length },
    { id: 'bahasa', name: 'Bahasa', count: examHistory.filter(e => e.category === 'bahasa').length },
    { id: 'fisika', name: 'Fisika', count: examHistory.filter(e => e.category === 'fisika').length },
    { id: 'kimia', name: 'Kimia', count: examHistory.filter(e => e.category === 'kimia').length },
  ]

  const filteredHistory = examHistory.filter(exam =>
    selectedFilter === 'all' || exam.category === selectedFilter
  )

  // Calculate statistics
  const averageScore = Math.round(examHistory.reduce((sum, exam) => sum + exam.score, 0) / examHistory.length)
  const totalExams = examHistory.length
  const bestScore = Math.max(...examHistory.map(exam => exam.score))
  const improvementTrend = examHistory.length > 1 ?
    examHistory[0].score - examHistory[examHistory.length - 1].score : 0

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2
      }
    }
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        stiffness: 100,
        damping: 12
      }
    }
  }

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-6"
    >
      {/* Header */}
      <motion.div
        variants={itemVariants}
        className="bg-gradient-to-r from-orange-500 to-orange-600 rounded-xl p-6 text-white relative overflow-hidden"
      >
        <motion.div
          className="absolute top-0 right-0 w-32 h-32 bg-white opacity-10 rounded-full"
          animate={{
            scale: [1, 1.2, 1],
            rotate: [0, 180, 360]
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: "linear"
          }}
        />

        <div className="relative z-10">
          <motion.h1
            className="text-3xl font-bold mb-2"
            initial={{ x: -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.3 }}
          >
            Histori Ujian
          </motion.h1>
          <motion.p
            className="text-orange-100"
            initial={{ x: -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.4 }}
          >
            Lihat perkembangan dan analisis hasil ujian Anda
          </motion.p>
        </div>
      </motion.div>

      {/* Statistics Cards */}
      <motion.div
        variants={containerVariants}
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4"
      >
        {/* Total Exams */}
        <motion.div
          variants={itemVariants}
          whileHover={{
            scale: 1.05,
            boxShadow: "0 20px 40px rgba(0, 0, 0, 0.1)"
          }}
          className="bg-white rounded-xl p-6 shadow-sm border border-gray-200 card-hover"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Ujian</p>
              <motion.p
                className="text-2xl font-bold text-gray-900"
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.5, stiffness: 200, damping: 20 }}
              >
                {totalExams}
              </motion.p>
            </div>
            <motion.div
              className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center"
              whileHover={{
                scale: 1.1,
                boxShadow: "0 0 20px rgba(59, 130, 246, 0.4)"
              }}
            >
              <FileText className="h-6 w-6 text-blue-600" />
            </motion.div>
          </div>
        </motion.div>

        {/* Average Score */}
        <motion.div
          variants={itemVariants}
          whileHover={{
            scale: 1.05,
            boxShadow: "0 20px 40px rgba(0, 0, 0, 0.1)"
          }}
          className="bg-white rounded-xl p-6 shadow-sm border border-gray-200 card-hover"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Rata-rata Nilai</p>
              <motion.p
                className="text-2xl font-bold text-gray-900"
                animate={{
                  color: ["#111827", "#10B981", "#111827"]
                }}
                transition={{ duration: 3, repeat: Infinity }}
              >
                {averageScore}
              </motion.p>
            </div>
            <motion.div
              className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center"
              animate={{
                y: [0, -5, 0]
              }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              <BarChart3 className="h-6 w-6 text-green-600" />
            </motion.div>
          </div>
        </motion.div>

        {/* Best Score */}
        <motion.div
          variants={itemVariants}
          whileHover={{
            scale: 1.05,
            boxShadow: "0 20px 40px rgba(0, 0, 0, 0.1)"
          }}
          className="bg-white rounded-xl p-6 shadow-sm border border-gray-200 card-hover"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Nilai Terbaik</p>
              <motion.p
                className="text-2xl font-bold text-gray-900"
                animate={{
                  textShadow: [
                    "0 0 0px rgba(251, 146, 60, 0)",
                    "0 0 10px rgba(251, 146, 60, 0.5)",
                    "0 0 0px rgba(251, 146, 60, 0)"
                  ]
                }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                {bestScore}
              </motion.p>
            </div>
            <motion.div
              className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center"
              animate={{
                rotate: [0, 10, -10, 0]
              }}
              transition={{ duration: 3, repeat: Infinity }}
            >
              <Trophy className="h-6 w-6 text-yellow-600" />
            </motion.div>
          </div>
        </motion.div>

        {/* Improvement */}
        <motion.div
          variants={itemVariants}
          whileHover={{
            scale: 1.05,
            boxShadow: "0 20px 40px rgba(0, 0, 0, 0.1)"
          }}
          className="bg-white rounded-xl p-6 shadow-sm border border-gray-200 card-hover"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Peningkatan</p>
              <motion.p
                className={`text-2xl font-bold ${improvementTrend >= 0 ? 'text-green-600' : 'text-red-600'}`}
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.8, stiffness: 200, damping: 20 }}
              >
                {improvementTrend >= 0 ? '+' : ''}{improvementTrend}
              </motion.p>
            </div>
            <motion.div
              className={`w-12 h-12 ${improvementTrend >= 0 ? 'bg-green-100' : 'bg-red-100'} rounded-lg flex items-center justify-center`}
              animate={{
                y: [0, -5, 0]
              }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              <TrendingUp className={`h-6 w-6 ${improvementTrend >= 0 ? 'text-green-600' : 'text-red-600'}`} />
            </motion.div>
          </div>
        </motion.div>
      </motion.div>

      {/* Filter */}
      <motion.div
        variants={itemVariants}
        className="bg-white rounded-xl p-6 shadow-sm border border-gray-200"
      >
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-gray-900">Filter Kategori</h3>
          <Button variant="outline" className="flex items-center space-x-2">
            <Filter className="h-4 w-4" />
            <span>Export</span>
          </Button>
        </div>

        <div className="flex flex-wrap gap-2">
          {filters.map((filter) => (
            <motion.button
              key={filter.id}
              onClick={() => setSelectedFilter(filter.id)}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                selectedFilter === filter.id
                  ? 'bg-orange-500 text-white shadow-md'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              {filter.name} ({filter.count})
            </motion.button>
          ))}
        </div>
      </motion.div>

      {/* Exam History List */}
      <motion.div
        variants={containerVariants}
        className="space-y-4"
      >
        {filteredHistory.map((exam, index) => (
          <motion.div
            key={exam.id}
            variants={itemVariants}
            whileHover={{
              scale: 1.01,
              boxShadow: "0 10px 25px rgba(0, 0, 0, 0.1)"
            }}
            className="bg-white rounded-xl p-6 shadow-sm border border-gray-200 card-hover"
          >
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
              {/* Left Section */}
              <div className="flex-1">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-1">
                      {exam.title}
                    </h3>
                    <div className="flex items-center space-x-4 text-sm text-gray-600">
                      <div className="flex items-center space-x-1">
                        <Calendar className="h-4 w-4" />
                        <span>{new Date(exam.date).toLocaleDateString('id-ID')}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Clock className="h-4 w-4" />
                        <span>{exam.duration}</span>
                      </div>
                    </div>
                  </div>

                  <motion.span
                    className={`px-3 py-1 rounded-full text-xs font-medium ${
                      exam.difficulty === 'Sulit' ? 'bg-red-100 text-red-800' :
                      exam.difficulty === 'Sedang' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-green-100 text-green-800'
                    }`}
                    whileHover={{ scale: 1.05 }}
                  >
                    {exam.difficulty}
                  </motion.span>
                </div>

                {/* Stats Grid */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                  <div className="text-center p-3 bg-gray-50 rounded-lg">
                    <p className="text-sm text-gray-600">Nilai</p>
                    <motion.p
                      className="text-xl font-bold text-gray-900"
                      animate={{
                        color: exam.score >= 90 ? "#10B981" : exam.score >= 80 ? "#F59E0B" : "#EF4444"
                      }}
                    >
                      {exam.score}
                    </motion.p>
                  </div>
                  <div className="text-center p-3 bg-gray-50 rounded-lg">
                    <p className="text-sm text-gray-600">Benar</p>
                    <p className="text-xl font-bold text-gray-900">
                      {exam.correctAnswers}/{exam.questions}
                    </p>
                  </div>
                  <div className="text-center p-3 bg-gray-50 rounded-lg">
                    <p className="text-sm text-gray-600">Peringkat</p>
                    <p className="text-xl font-bold text-gray-900">
                      #{exam.rank}
                    </p>
                  </div>
                  <div className="text-center p-3 bg-gray-50 rounded-lg">
                    <p className="text-sm text-gray-600">Peserta</p>
                    <p className="text-xl font-bold text-gray-900">
                      {exam.totalParticipants}
                    </p>
                  </div>
                </div>

                {/* Progress Bar */}
                <div className="mb-4">
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-gray-600">Akurasi</span>
                    <span className="font-medium">{Math.round((exam.correctAnswers / exam.questions) * 100)}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${(exam.correctAnswers / exam.questions) * 100}%` }}
                      transition={{ duration: 1, delay: 0.5 + index * 0.1 }}
                      className={`h-2 rounded-full ${
                        exam.score >= 90 ? 'bg-green-500' :
                        exam.score >= 80 ? 'bg-yellow-500' : 'bg-red-500'
                      }`}
                    />
                  </div>
                </div>
              </div>

              {/* Right Section - Actions */}
              <div className="flex flex-col space-y-2 lg:ml-6">
                <motion.div
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Button
                    variant="outline"
                    size="sm"
                    className="w-full lg:w-auto btn-hover-lift"
                  >
                    <Eye className="h-4 w-4 mr-2" />
                    Lihat Detail
                  </Button>
                </motion.div>
                <motion.div
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Button
                    variant="outline"
                    size="sm"
                    className="w-full lg:w-auto btn-hover-lift"
                  >
                    <Download className="h-4 w-4 mr-2" />
                    Download
                  </Button>
                </motion.div>
              </div>
            </div>
          </motion.div>
        ))}
      </motion.div>

      {/* Empty State */}
      {filteredHistory.length === 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center py-12"
        >
          <motion.div
            animate={{
              y: [0, -10, 0]
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          >
            <FileText className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          </motion.div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            Belum ada histori ujian
          </h3>
          <p className="text-gray-600">
            Mulai mengerjakan tryout untuk melihat histori ujian Anda
          </p>
        </motion.div>
      )}
    </motion.div>
  )
}
