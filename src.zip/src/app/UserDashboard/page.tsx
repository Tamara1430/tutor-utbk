import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Dashboard',
  description: 'Dashboard utama StudyPlatform dengan statistik belajar, aktivitas terbaru, dan tryout mendatang.',
}

export { default } from './dashboard-page'

