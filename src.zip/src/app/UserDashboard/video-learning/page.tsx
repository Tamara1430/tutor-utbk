'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import {
  Play,
  Eye,
  BookOpen,
  Star,
  Search,
  Filter,
  PlayCircle
} from 'lucide-react'
import { Button } from '@/components/ui/button'

export default function VideoLearning() {
  const [selectedCategory, setSelectedCategory] = useState('all')
  const [searchTerm, setSearchTerm] = useState('')

  // Data dummy untuk video pembelajaran
  const videos = [
    {
      id: 1,
      title: 'Integral dan Diferensial - Konsep Dasar',
      description: 'Pelajari konsep dasar integral dan diferensial dengan penjelasan yang mudah dipahami',
      duration: '45:30',
      views: 12500,
      rating: 4.8,
      category: 'matematika',
      level: 'Menengah',
      instructor: 'Dr. Ahmad Matematika',
      thumbnail: '/api/placeholder/400/225',
      isNew: true
    },
    {
      id: 2,
      title: 'Tata Bahasa Indonesia Modern',
      description: 'Memahami struktur dan kaidah bahasa Indonesia yang benar sesuai EYD terbaru',
      duration: '32:15',
      views: 8900,
      rating: 4.6,
      category: 'bahasa',
      level: 'Dasar',
      instructor: 'Prof. Sari Bahasa',
      thumbnail: '/api/placeholder/400/225',
      isNew: false
    },
    {
      id: 3,
      title: 'Hukum Newton dan Aplikasinya',
      description: 'Eksplorasi mendalam tentang hukum-hukum Newton dan penerapannya dalam kehidupan sehari-hari',
      duration: '38:45',
      views: 15200,
      rating: 4.9,
      category: 'fisika',
      level: 'Menengah',
      instructor: 'Dr. Budi Fisika',
      thumbnail: '/api/placeholder/400/225',
      isNew: true
    },
    {
      id: 4,
      title: 'Reaksi Kimia dan Stoikiometri',
      description: 'Memahami berbagai jenis reaksi kimia dan perhitungan stoikiometri',
      duration: '41:20',
      views: 9800,
      rating: 4.7,
      category: 'kimia',
      level: 'Lanjutan',
      instructor: 'Dr. Rina Kimia',
      thumbnail: '/api/placeholder/400/225',
      isNew: false
    }
  ]

  const categories = [
    { id: 'all', name: 'Semua', count: videos.length },
    { id: 'matematika', name: 'Matematika', count: videos.filter(v => v.category === 'matematika').length },
    { id: 'bahasa', name: 'Bahasa', count: videos.filter(v => v.category === 'bahasa').length },
    { id: 'fisika', name: 'Fisika', count: videos.filter(v => v.category === 'fisika').length },
    { id: 'kimia', name: 'Kimia', count: videos.filter(v => v.category === 'kimia').length },
  ]

  const filteredVideos = videos.filter(video => {
    const matchesCategory = selectedCategory === 'all' || video.category === selectedCategory
    const matchesSearch = video.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      video.description.toLowerCase().includes(searchTerm.toLowerCase())
    return matchesCategory && matchesSearch
  })

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2
      }
    }
  }

  // Sudah tidak ada "type"
  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        stiffness: 100,
        damping: 12
      }
    }
  }

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-6"
    >
      {/* Header */}
      <motion.div
        variants={itemVariants}
        className="bg-gradient-to-r from-purple-500 to-purple-600 rounded-xl p-6 text-white relative overflow-hidden"
      >
        <motion.div
          className="absolute top-0 right-0 w-32 h-32 bg-white opacity-10 rounded-full"
          animate={{
            scale: [1, 1.2, 1],
            rotate: [0, 180, 360]
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: "linear"
          }}
        />
        <div className="relative z-10">
          <motion.h1
            className="text-3xl font-bold mb-2"
            initial={{ x: -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.3 }}
          >
            Video Pembelajaran
          </motion.h1>
          <motion.p
            className="text-purple-100"
            initial={{ x: -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.4 }}
          >
            Belajar dengan video berkualitas tinggi dari instruktur terbaik
          </motion.p>
        </div>
      </motion.div>

      {/* Search and Filter */}
      <motion.div
        variants={itemVariants}
        className="bg-white rounded-xl p-6 shadow-sm border border-gray-200"
      >
        <div className="flex flex-col md:flex-row gap-4">
          {/* Search */}
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                placeholder="Cari video pembelajaran..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              />
            </div>
          </div>
          {/* Filter Button */}
          <Button variant="outline" className="flex items-center space-x-2">
            <Filter className="h-4 w-4" />
            <span>Filter</span>
          </Button>
        </div>

        {/* Categories */}
        <div className="flex flex-wrap gap-2 mt-4">
          {categories.map((category) => (
            <motion.button
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                selectedCategory === category.id
                  ? 'bg-purple-500 text-white shadow-md'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              {category.name} ({category.count})
            </motion.button>
          ))}
        </div>
      </motion.div>

      {/* Video Grid */}
      <motion.div
        variants={containerVariants}
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
      >
        {filteredVideos.map((video, index) => (
          <motion.div
            key={video.id}
            variants={itemVariants}
            whileHover={{
              scale: 1.02,
              boxShadow: "0 20px 40px rgba(0, 0, 0, 0.1)"
            }}
            className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden card-hover"
          >
            {/* Thumbnail */}
            <div className="relative h-48 bg-gradient-to-br from-purple-100 to-pink-100 overflow-hidden group">
              <motion.div
                className="absolute inset-0 bg-gradient-to-br from-purple-400 to-pink-500 opacity-80"
                whileHover={{ opacity: 0.9 }}
              />
              {/* Play Button Overlay */}
              <motion.div
                className="absolute inset-0 flex items-center justify-center"
                whileHover={{ scale: 1.1 }}
              >
                <motion.div
                  whileHover={{ scale: 1.2 }}
                  whileTap={{ scale: 0.9 }}
                  className="w-16 h-16 bg-white bg-opacity-90 rounded-full flex items-center justify-center cursor-pointer shadow-lg"
                >
                  <Play className="h-8 w-8 text-purple-600 ml-1" />
                </motion.div>
              </motion.div>
              {/* Duration Badge */}
              <div className="absolute bottom-4 right-4 bg-black bg-opacity-70 text-white px-2 py-1 rounded text-xs font-medium">
                {video.duration}
              </div>
              {/* New Badge */}
              {video.isNew && (
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.5 + index * 0.1 }}
                  className="absolute top-4 left-4 bg-red-500 text-white px-2 py-1 rounded-full text-xs font-medium"
                >
                  Baru
                </motion.div>
              )}
            </div>
            {/* Content */}
            <div className="p-6">
              <div className="flex items-start justify-between mb-3">
                <h3 className="text-lg font-semibold text-gray-900 line-clamp-2">
                  {video.title}
                </h3>
                <motion.div
                  className="flex items-center space-x-1 ml-2"
                  whileHover={{ scale: 1.05 }}
                >
                  <Star className="h-4 w-4 text-yellow-400 fill-current" />
                  <span className="text-sm text-gray-600">{video.rating}</span>
                </motion.div>
              </div>
              <p className="text-gray-600 text-sm mb-4 line-clamp-2">
                {video.description}
              </p>
              {/* Instructor */}
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                  <BookOpen className="h-4 w-4 text-purple-600" />
                </div>
                <span className="text-sm text-gray-700 font-medium">{video.instructor}</span>
              </div>
              {/* Stats */}
              <div className="flex items-center justify-between mb-4">
                <motion.div
                  className="flex items-center space-x-1 text-gray-600"
                  whileHover={{ scale: 1.05 }}
                >
                  <Eye className="h-4 w-4" />
                  <span className="text-sm">{video.views.toLocaleString()} views</span>
                </motion.div>
                <motion.span
                  className={`px-3 py-1 rounded-full text-xs font-medium ${
                    video.level === 'Lanjutan' ? 'bg-red-100 text-red-800' :
                    video.level === 'Menengah' ? 'bg-yellow-100 text-yellow-800' :
                    'bg-green-100 text-green-800'
                  }`}
                  whileHover={{ scale: 1.05 }}
                >
                  {video.level}
                </motion.span>
              </div>
              {/* Action Button */}
              <motion.div
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <Button
                  className="w-full bg-purple-500 hover:bg-purple-600 text-white btn-hover-lift"
                >
                  <PlayCircle className="h-4 w-4 mr-2" />
                  Tonton Video
                </Button>
              </motion.div>
            </div>
          </motion.div>
        ))}
      </motion.div>

      {/* Empty State */}
      {filteredVideos.length === 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center py-12"
        >
          <motion.div
            animate={{
              y: [0, -10, 0]
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          >
            <Play className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          </motion.div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            Tidak ada video ditemukan
          </h3>
          <p className="text-gray-600">
            Coba ubah kata kunci pencarian atau filter kategori
          </p>
        </motion.div>
      )}
    </motion.div>
  )
}
