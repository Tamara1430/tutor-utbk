'use client';

import Header from './core/header'
import AboutUs from './core/aboutus'
import Testing from './core/Testing'
import Contact from './core/Contact'
import Footer from './core/Footer'


export default function HomePage() {
  return (
    <>
      <Header />
      <AboutUs />
      <Testing />
      <Contact />
      <Footer />
    </>
  );
}
