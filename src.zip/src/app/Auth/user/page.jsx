'use client';
import React, { useState, useEffect } from 'react';
import { initializeApp } from 'firebase/app';
import { 
  getAuth, 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword 
} from 'firebase/auth';
import { 
  getFirestore, 
  collection, 
  query, 
  where, 
  getDocs, 
  addDoc, 
  doc 
} from 'firebase/firestore';
import '../auth.css';

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyD9BhhgzA2D0DPQKapDe2M2wR7U0u7nOu4",
  authDomain: "utbk-2fca1.firebaseapp.com",
  projectId: "utbk-2fca1",
  storageBucket: "utbk-2fca1.appspot.com",
  messagingSenderId: "317409113218",
  appId: "1:317409113218:web:dd902046c75208bfa9309b",
  measurementId: "G-YC7Y7MB13W",
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

// Mata SVG
function EyeIcon({ visible }) {
  return visible ? (
    // Mata terbuka
    <svg width="22" height="22" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <circle cx="12" cy="12" r="3" strokeWidth="2"/>
      <path d="M2 12S5.5 5 12 5s10 7 10 7-3.5 7-10 7S2 12 2 12z" strokeWidth="2"/>
    </svg>
  ) : (
    // Mata dicoret
    <svg width="22" height="22" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <circle cx="12" cy="12" r="3" strokeWidth="2"/>
      <path d="M2 12S5.5 5 12 5s10 7 10 7-3.5 7-10 7S2 12 2 12z" strokeWidth="2"/>
      <line x1="3" y1="3" x2="21" y2="21" strokeWidth="2"/>
    </svg>
  );
}

export default function AuthPages() {
  const [page, setPage] = useState('login');
  const [tutorId, setTutorId] = useState('');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  // Untuk show/hide password
  const [showPassword, setShowPassword] = useState(false);
  const [showRegPassword, setShowRegPassword] = useState(false);
  const [showRegConfirm, setShowRegConfirm] = useState(false);

  useEffect(() => {
    const storedTutorId = localStorage.getItem('tutor_uid');
    if (!storedTutorId) {
      alert('Unknow Eror');
      window.location.href = '../auth';
    } else {
      setTutorId(storedTutorId);
      console.log('Tutor ID:', storedTutorId);
    }
  }, []);

  const handleLogin = async () => {
    if (!username || !password) {
      return alert('Username dan password harus diisi!');
    }
    try {
      const userQuery = query(
        collection(db, 'tutor', tutorId, 'user'),
        where('username', '==', username)
      );
      const querySnapshot = await getDocs(userQuery);
      if (querySnapshot.empty) {
        return alert('Username tidak ditemukan!');
      }
      const userData = querySnapshot.docs[0].data();
      const userEmail = userData.email;
      const userId = querySnapshot.docs[0].id;

      await signInWithEmailAndPassword(auth, userEmail, password);
      localStorage.setItem('user_uid', userId);
      console.log('UID User:', userId);

      alert('Login berhasil!');
      window.location.href = '../UserDashboard';
    } catch (err) {
      alert('Error: ' + err.message);
    }
  };

  const handleRegister = async () => {
    if (!username || !email || !password || !confirmPassword) {
      return alert('Semua kolom wajib diisi!');
    }
    if (password !== confirmPassword) {
      return alert('Password tidak cocok!');
    }
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;

      const tutorRef = doc(db, 'tutor', tutorId);
      const userRef = collection(tutorRef, 'user');

      // Check if username already exists
      const userQuery = query(userRef, where('username', '==', username));
      const querySnapshot = await getDocs(userQuery);
      if (!querySnapshot.empty) {
        alert('Username sudah digunakan.');
        return;
      }

      await addDoc(userRef, {
        uid: user.uid,
        username,
        email,
      });

      alert('Registrasi berhasil!');
      setPage('login');
    } catch (err) {
      console.error('Error during registration:', err);
      alert('Error: ' + err.message);
    }
  };

  // Komponen password dengan tombol mata
  const PasswordInput = ({
    value, onChange, placeholder,
    show, setShow, name = "Password"
  }) => (
    <div style={{ position: 'relative', width: '100%' }}>
      <input
        className="input"
        type={show ? 'text' : 'password'}
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        autoComplete="off"
        style={{ paddingRight: 36 }}
      />
      <button
        type="button"
        aria-label={show ? 'Sembunyikan password' : 'Tampilkan password'}
        onClick={() => setShow(!show)}
        style={{
          position: 'absolute', right: 10, top: '50%',
          transform: 'translateY(-50%)',
          background: 'none', border: 'none', padding: 0, cursor: 'pointer'
        }}
        tabIndex={-1}
      >
        <EyeIcon visible={show} />
      </button>
    </div>
  );

  return (
    <div className="wrapper">
      {page === 'login' ? (
        <>
          <h4 className="header">SELAMAT DATANG! Login Sekarang!</h4>
          <p className="tulisan">Nama Kamu</p>
          <input
            className="input"
            type="text"
            value={username}
            onChange={e => setUsername(e.target.value)}
            placeholder="Masukkan Nama"
            autoComplete="username"
          />
          <p className="tulisan">Password</p>
          <PasswordInput
            value={password}
            onChange={e => setPassword(e.target.value)}
            placeholder="Masukkan Password"
            show={showPassword}
            setShow={setShowPassword}
          />
          <button className="masuk" onClick={handleLogin}>Masuk Sekarang</button>
          <p className="tulisan">
            Belum Punya Akun?{' '}
            <b onClick={() => setPage('register')} style={{ cursor: 'pointer' }}>
              Daftar
            </b>
          </p>
        </>
      ) : (
        <>
          <h4 className="header">SELAMAT DATANG! Daftar jadi member kami!</h4>
          <p className="tulisan">Nama Kamu</p>
          <input
            className="input"
            type="text"
            value={username}
            onChange={e => setUsername(e.target.value)}
            placeholder="Masukkan Nama"
            autoComplete="username"
          />
          <p className="tulisan">Email</p>
          <input
            className="input"
            type="email"
            value={email}
            onChange={e => setEmail(e.target.value)}
            placeholder="Masukkan Email"
            autoComplete="email"
          />
          <p className="tulisan">Password</p>
          <PasswordInput
            value={password}
            onChange={e => setPassword(e.target.value)}
            placeholder="Masukkan Password"
            show={showRegPassword}
            setShow={setShowRegPassword}
          />
          <p className="tulisan">Konfirmasi Password</p>
          <PasswordInput
            value={confirmPassword}
            onChange={e => setConfirmPassword(e.target.value)}
            placeholder="Konfirmasi Password"
            show={showRegConfirm}
            setShow={setShowRegConfirm}
          />
          <button className="masuk" onClick={handleRegister}>Daftar</button>
          <p className="tulisan">
            Sudah Punya Akun?{' '}
            <b onClick={() => setPage('login')} style={{ cursor: 'pointer' }}>
              Masuk
            </b>
          </p>
        </>
      )}
    </div>
  );
}
