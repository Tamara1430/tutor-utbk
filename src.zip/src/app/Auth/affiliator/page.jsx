'use client'
import React, { useState } from 'react';
import { initializeApp } from 'firebase/app';
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword } from 'firebase/auth';
import { getFirestore, collection, query, where, getDocs, addDoc } from 'firebase/firestore';
import '../auth.css';

import { auth, db } from '../../firebase/config'; // Pastikan path sesuai lokasi firebase.js
import { createUserWithEmailAndPassword, signInWithEmailAndPassword } from 'firebase/auth';
import { collection, query, where, getDocs, addDoc } from 'firebase/firestore';

export default function AuthPages() {
  const [page, setPage] = useState('login');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const handleLogin = async () => {
    if (!username || !password) return alert("Username dan password harus diisi!");

    try {
      const q = query(collection(db, "Affiliator"), where("username", "==", username));
      const querySnapshot = await getDocs(q);
      if (querySnapshot.empty) return alert("Username tidak ditemukan!");
      let userEmail = querySnapshot.docs[0].data().email;
      await signInWithEmailAndPassword(auth, userEmail, password);
      alert("Login berhasil!");
      window.location.href = "../AffiliateDashboard";
    } catch (err) {
      alert("Error: " + err.message);
    }
  };

  const handleRegister = async () => {
    if (!username || !email || !password || !confirmPassword) return alert("Semua kolom wajib diisi!");
    if (password !== confirmPassword) return alert("Password tidak cocok!");

    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      await addDoc(collection(db, "Affiliator"), {
        uid: userCredential.user.uid,
        username,
        email
      });
      alert("Registrasi berhasil!");
      setPage('login');
    } catch (err) {
      alert("Error: " + err.message);
    }
  };

  return (
    <div className="wrapper">
      {page === 'login' ? (
        <>
          <h4 className="header">SELAMAT DATANG! Login Sekarang!</h4>
          <p className="tulisan">Nama Kamu</p>
          <input className="input" type="text" value={username} onChange={e => setUsername(e.target.value)} placeholder="Masukkan Nama" />
          <p className="tulisan">Password</p>
          <input className="input" type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Masukkan Password" />
          <button className="masuk" onClick={handleLogin}>Masuk Sekarang</button>
          <p className="tulisan">Belum Punya Akun? <b onClick={() => setPage('register')} style={{cursor: 'pointer'}}>Daftar</b></p>
        </>
      ) : (
        <>
          <h4 className="header">SELAMAT DATANG! Daftar jadi member kami!</h4>
          <p className="tulisan">Nama Kamu</p>
          <input className="input" type="text" value={username} onChange={e => setUsername(e.target.value)} placeholder="Masukkan Nama" />
          <p className="tulisan">Email</p>
          <input className="input" type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="Masukkan Email" />
          <p className="tulisan">Password</p>
          <input className="input" type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Masukkan Password" />
          <p className="tulisan">Konfirmasi Password</p>
          <input className="input" type="password" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} placeholder="Konfirmasi Password" />
          <button className="masuk" onClick={handleRegister}>Daftar</button>
          <p className="tulisan">Sudah Punya Akun? <b onClick={() => setPage('login')} style={{cursor: 'pointer'}}>Masuk</b></p>
        </>
      )}
    </div>
  );
}
