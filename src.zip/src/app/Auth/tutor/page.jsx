'use client';
import React, { useState } from 'react';
import { auth, db } from '../../firebase/config';
import { createUserWithEmailAndPassword, signInWithEmailAndPassword } from 'firebase/auth';
import { collection, query, where, getDocs, addDoc } from 'firebase/firestore';
import '../auth.css';
import { Modal, Button } from 'react-bootstrap';

// Komponen Icon Mata
function EyeIcon({ show }) {
  return show ? (
    <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <circle cx="12" cy="12" r="3" strokeWidth="2"/>
      <path d="M2 12S5.5 5 12 5s10 7 10 7-3.5 7-10 7S2 12 2 12z" strokeWidth="2"/>
    </svg>
  ) : (
    <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <circle cx="12" cy="12" r="3" strokeWidth="2"/>
      <path d="M2 12S5.5 5 12 5s10 7 10 7-3.5 7-10 7S2 12 2 12z" strokeWidth="2"/>
      <line x1="3" y1="3" x2="21" y2="21" strokeWidth="2"/>
    </svg>
  );
}

// Komponen Modal Bootstrap
function InfoModal({ show, onHide, title, body, onOk }) {
  return (
    <Modal show={show} onHide={onHide} centered>
      <Modal.Header closeButton>
        <Modal.Title style={{ fontWeight: 'bold' }}>{title}</Modal.Title>
      </Modal.Header>
      <Modal.Body>{body}</Modal.Body>
      <Modal.Footer>
        <Button variant="primary" onClick={onOk || onHide}>
          OK
        </Button>
      </Modal.Footer>
    </Modal>
  );
}

export default function AuthPages() {
  const [page, setPage] = useState('login');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  // Mata
  const [showPassword, setShowPassword] = useState(false);
  const [showRegPassword, setShowRegPassword] = useState(false);
  const [showRegConfirm, setShowRegConfirm] = useState(false);

  // State Modal
  const [modal, setModal] = useState({
    show: false,
    title: '',
    body: '',
    onOk: null
  });

  const showModal = (title, body, onOk = null) => {
    setModal({ show: true, title, body, onOk });
  };

  const hideModal = () => setModal({ ...modal, show: false });

  const handleLogin = async () => {
    if (!username || !password) {
      return showModal('Peringatan', 'Username dan password harus diisi!');
    }
    try {
      const q = query(collection(db, "tutor"), where("username", "==", username));
      const querySnapshot = await getDocs(q);
      if (querySnapshot.empty) {
        return showModal('Error', 'Username tidak ditemukan!');
      }
      const userData = querySnapshot.docs[0].data();
      const userEmail = userData.email;
      const userId = querySnapshot.docs[0].id;

      await signInWithEmailAndPassword(auth, userEmail, password);
      localStorage.setItem("tutor_uid", userId);

      showModal('Sukses', 'Login berhasil!', () => {
        hideModal();
        window.location.href = "../TutorDashboard";
      });
    } catch (err) {
      showModal('Error', err.message);
    }
  };

  const handleRegister = async () => {
    if (!username || !email || !password || !confirmPassword) {
      return showModal('Peringatan', 'Semua kolom wajib diisi!');
    }
    if (password !== confirmPassword) {
      return showModal('Peringatan', 'Password tidak cocok!');
    }
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      await addDoc(collection(db, "tutor"), {
        uid: userCredential.user.uid,
        username,
        email
      });
      showModal('Sukses', 'Registrasi berhasil!', () => {
        hideModal();
        setPage('login');
      });
    } catch (err) {
      showModal('Error', err.message);
    }
  };

  return (
    <div className="wrapper">
      <InfoModal show={modal.show} onHide={hideModal} title={modal.title} body={modal.body} onOk={modal.onOk} />
      {page === 'login' ? (
        <>
          <h4 className="header">SELAMAT DATANG! Login Sekarang!</h4>
          <p className="tulisan">Nama Kamu</p>
          <input className="input" type="text" value={username} onChange={e => setUsername(e.target.value)} placeholder="Masukkan Nama" />
          <p className="tulisan">Password</p>
          <div style={{ position: "relative" }}>
            <input
              className="input"
              type={showPassword ? "text" : "password"}
              value={password}
              onChange={e => setPassword(e.target.value)}
              placeholder="Masukkan Password"
              style={{ paddingRight: 36 }}
            />
            <button
              type="button"
              onClick={() => setShowPassword(v => !v)}
              style={{
                position: "absolute",
                right: 10,
                top: "37%",
                transform: "translateY(-50%)",
                background: "none",
                border: "none",
                padding: 0,
                cursor: "pointer"
              }}
              tabIndex={-1}
            >
              <EyeIcon show={showPassword} />
            </button>
          </div>
          <button className="masuk" onClick={handleLogin}>Masuk Sekarang</button>
          <p className="tulisan">Belum Punya Akun? <b onClick={() => setPage('register')} style={{cursor: 'pointer'}}>Daftar</b></p>
        </>
      ) : (
        <>
          <h4 className="header">SELAMAT DATANG! Daftar jadi member kami!</h4>
          <p className="tulisan">Nama Kamu</p>
          <input className="input" type="text" value={username} onChange={e => setUsername(e.target.value)} placeholder="Masukkan Nama" />
          <p className="tulisan">Email</p>
          <input className="input" type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="Masukkan Email" />
          <p className="tulisan">Password</p>
          <div style={{ position: "relative" }}>
            <input
              className="input"
              type={showRegPassword ? "text" : "password"}
              value={password}
              onChange={e => setPassword(e.target.value)}
              placeholder="Masukkan Password"
              style={{ paddingRight: 36 }}
            />
            <button
              type="button"
              onClick={() => setShowRegPassword(v => !v)}
              style={{
                position: "absolute",
                right: 10,
                top: "37%",
                transform: "translateY(-50%)",
                background: "none",
                border: "none",
                padding: 0,
                cursor: "pointer"
              }}
              tabIndex={-1}
            >
              <EyeIcon show={showRegPassword} />
            </button>
          </div>
          <p className="tulisan">Konfirmasi Password</p>
          <div style={{ position: "relative" }}>
            <input
              className="input"
              type={showRegConfirm ? "text" : "password"}
              value={confirmPassword}
              onChange={e => setConfirmPassword(e.target.value)}
              placeholder="Konfirmasi Password"
              style={{ paddingRight: 36 }}
            />
            <button
              type="button"
              onClick={() => setShowRegConfirm(v => !v)}
              style={{
                position: "absolute",
                right: 10,
                top: "37%",
                transform: "translateY(-50%)",
                background: "none",
                border: "none",
                padding: 0,
                cursor: "pointer"
              }}
              tabIndex={-1}
            >
              <EyeIcon show={showRegConfirm} />
            </button>
          </div>
          <button className="masuk" onClick={handleRegister}>Daftar</button>
          <p className="tulisan">Sudah Punya Akun? <b onClick={() => setPage('login')} style={{cursor: 'pointer'}}>Masuk</b></p>
        </>
      )}
    </div>
  );
}
