'use client'
import React, { useState } from "react";

const AffiliateDashboard = () => {
  const [incomeData] = useState({
    monthlyCommission: 4200000,
    totalCommission: 15000000,
    withdrawableBalance: 3500000,
  });

  // Example quest states
  const [quests, setQuests] = useState([
    {
      id: 1,
      title: "Dapatkan 5 Referral Baru",
      description: "Ajak 5 orang bergabung melalui link affiliate Anda",
      progress: 3,
      goal: 5,
      reward: "1 Kelas Gratis",
    },
    {
      id: 2,
      title: "Hasilkan Komisi Rp. 10.000.000",
      description: "Capai komisi total 10 juta rupiah",
      progress: incomeData.totalCommission,
      goal: 10000000,
      reward: "1 Kelas Gratis",
    },
  ]);

  const [isEditing, setIsEditing] = useState(false);
  const [revealCode, setRevealCode] = useState('');
  const [savedCode, setSavedCode] = useState('');

  const handleSave = () => {
    setSavedCode(revealCode);
    setIsEditing(false);
  };

  // Check if quests are completed
  const isQuestCompleted = (quest) => quest.progress >= quest.goal;

  

  return (
    <>
      <style>{`
        * {
          box-sizing: border-box;
        }
        body {
          margin: 0;
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,
            Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
          background-color: #f5f7fa;
          color: #333;
        }
        .dashboard-container {
          max-width: 900px;
          margin: 1rem auto;
          padding: 1rem;
          background: white;
          border-radius: 8px;
          box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        h1 {
          font-size: 1.8rem;
          margin-bottom: 1rem;
          text-align: center;
          color: #2c3e50;
        }
        section {
          margin-bottom: 2rem;
        }
        .income-summary {
          display: flex;
          flex-wrap: wrap;
          justify-content: space-around;
          gap: 1rem;
        }
        .income-box {
          flex: 1 1 200px;
          background-color: #8e44ad;
          color: white;
          padding: 1.2rem;
          border-radius: 8px;
          text-align: center;
          box-shadow: 0 3px 6px rgba(142,68,173,0.4);
          transition: background-color 0.3s ease;
        }
        .income-box:hover {
          background-color: #732d91;
          cursor: default;
        }
        .income-box h3 {
          margin: 0.2rem 0;
          font-weight: 700;
          font-size: 1.2rem;
        }
        .income-box p {
          margin: 0;
          font-size: 1.7rem;
          font-weight: 700;
          letter-spacing: 0.02em;
        }
        .quests {
          background: #ecf0f1;
          padding: 1rem 1.5rem;
          border-radius: 8px;
          box-shadow: inset 0 0 8px rgb(0 0 0 / 0.1);
        }
        .quest-item {
          border: 2px solid #8e44ad;
          border-radius: 8px;
          padding: 1rem;
          margin-bottom: 1rem;
          background-color: white;
          transition: box-shadow 0.3s ease;
        }
        .quest-item.completed {
          border-color: #27ae60;
          background-color: #e8f5e9;
          box-shadow: 0 0 10px #27ae60aa;
        }
        .quest-title {
          font-weight: 700;
          font-size: 1.1rem;
          color: #5d2c86;
          margin-bottom: 0.3rem;
        }
        .quest-description {
          font-size: 0.95rem;
          margin-bottom: 0.5rem;
          color: #555;
        }
        .quest-progress {
          font-size: 0.9rem;
          font-weight: 600;
          color: #333;
          margin-bottom: 0.5rem;
        }
        .quest-reward {
          font-weight: 700;
          font-size: 1rem;
          color: #27ae60;
        }
        @media (max-width: 600px) {
          .income-summary {
            flex-direction: column;
            align-items: stretch;
          }
          .income-box {
            flex: 1 1 100%;
          }
        }
      `}</style>

      <div className="dashboard-container" role="main" aria-label="Affiliate Dashboard">
        <h1>Dashboard Affiliate</h1>

        <section aria-label="Pendapatan Komisi">
          <h2>Pendapatan Komisi</h2>
          <div className="income-summary">
            <div className="income-box" tabIndex="0" aria-live="polite">
              <h3>Komisi Bulanan</h3>
              <p>{incomeData.monthlyCommission.toLocaleString("id-ID", { style: "currency", currency: "IDR", minimumFractionDigits: 0 })}</p>
            </div>
            <div className="income-box" tabIndex="0" aria-live="polite">
              <h3>Total Komisi</h3>
              <p>{incomeData.totalCommission.toLocaleString("id-ID", { style: "currency", currency: "IDR", minimumFractionDigits: 0 })}</p>
            </div>
            <div className="income-box" tabIndex="0" aria-live="polite">
              <h3>Saldo Dapat Ditarik</h3>
              <p>{incomeData.withdrawableBalance.toLocaleString("id-ID", { style: "currency", currency: "IDR", minimumFractionDigits: 0 })}</p>
            </div>
          </div>
        </section>

        <section aria-label="Quest khusus affiliate" className="quests">
          <h2>Quest Khusus</h2>
          {quests.map((quest) => {
            const completed = isQuestCompleted(quest);
            return (
              <div
                key={quest.id}
                className={`quest-item${completed ? " completed" : ""}`}
                tabIndex="0"
                aria-describedby={`quest-desc-${quest.id} quest-progress-${quest.id} quest-reward-${quest.id}`}
                aria-live="polite"
              >
                <div className="quest-title">{quest.title}</div>
                <div id={`quest-desc-${quest.id}`} className="quest-description">{quest.description}</div>
                <div id={`quest-progress-${quest.id}`} className="quest-progress">
                  Progress: {completed ? quest.goal : quest.progress} / {quest.goal}
                </div>
                {completed && (
                  <div id={`quest-reward-${quest.id}`} className="quest-reward" aria-label="Hadiah quest">
                    🎉 Selamat! Anda mendapatkan {quest.reward}
                  </div>
                )}
              </div>
            );
          })}
        </section>
      </div>
      <section aria-label="Kode Unik" className="quests">
        <h2>Kode Reveal</h2>
        <input
          type="text"
          placeholder=" Reveal Code"
          value={isEditing ? revealCode : savedCode}
          onChange={(e) => setRevealCode(e.target.value)}
          style={{ backgroundColor: "white", color: "black" }}
          readOnly={!isEditing}
        />
        <div style={{ marginTop: "0.5rem" }}>
          {isEditing ? (
            <button onClick={handleSave}>Simpan</button>
          ) : (
            <button onClick={() => {
              setRevealCode(savedCode);
              setIsEditing(true);
            }}>
              Edit
            </button>
          )}
        </div>
      </section>
    </>
  );
};


export default AffiliateDashboard;


