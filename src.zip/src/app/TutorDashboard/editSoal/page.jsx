"use client";
import React, { useState, useEffect } from "react";
import "./style.css";
import {
  addDoc, collection, query, where, getDocs, onSnapshot
} from "firebase/firestore";
import { db, auth } from "../../firebase/config.js";
import { onAuthStateChanged } from "firebase/auth";

function getQueryParam(param) {
  if (typeof window === "undefined") return null;
  const url = new URL(window.location.href);
  return url.searchParams.get(param);
}

const AdminDashboard = () => {
  const [questions, setQuestions] = useState([]);
  const [newQuestion, setNewQuestion] = useState({
    type: "multipleChoice",
    statement: "",
    options: [
      { label: "A", text: "" },
      { label: "B", text: "" },
      { label: "C", text: "" },
      { label: "D", text: "" },
    ],
    answer: "",
  });

  const [loading, setLoading] = useState(true);
  const [sesi, setSesi] = useState("");
  const [subtest, setSubtest] = useState("");
  const [tutorDocId, setTutorDocId] = useState("");

  // Ambil sesi & subtest dari URL query param
  useEffect(() => {
    const sesiName = getQueryParam("sesi");
    const subtestName = getQueryParam("subtest");
    if (!sesiName || !subtestName) {
      alert("Pilih sesi dan subtest terlebih dahulu.");
      window.location.href = "/TutorDashboard/pilihSesi";
      return;
    }
    setSesi(sesiName);
    setSubtest(subtestName);
  }, []);

  // Fetch questions from Firestore sesuai sesi & subtest yang dipilih
  useEffect(() => {
    if (!sesi || !subtest) return;
    const unsubscribeAuth = onAuthStateChanged(auth, async (user) => {
      if (user) {
        const tutorRef = collection(db, "tutor");
        const q = query(tutorRef, where("uid", "==", user.uid));
        const querySnapshot = await getDocs(q);

        if (!querySnapshot.empty) {
          const tutorDoc = querySnapshot.docs[0];
          setTutorDocId(tutorDoc.id);

          // --- FIXED PATH ---
          const questionsRef = collection(
            db,
            "tutor",
            tutorDoc.id,
            "Soal",
            sesi,
            "subtest",
            subtest,
            "questions"
          );

          const unsubscribeQuestions = onSnapshot(questionsRef, (snapshot) => {
            const fetchedQuestions = snapshot.docs.map(doc => ({
              id: doc.id,
              ...doc.data()
            }));
            setQuestions(fetchedQuestions);
            setLoading(false);
          });

          // Cleanup saat unmount
          return () => unsubscribeQuestions();
        }
      }
    });

    // Cleanup listener auth saat unmount
    return () => unsubscribeAuth();
  }, [sesi, subtest]);

  const handleInputChange = (e, index = null) => {
    const { name, value } = e.target;

    if (name === "statement") {
      setNewQuestion((prev) => ({ ...prev, statement: value }));
    } else if (name === "type") {
      if (value === "multipleChoice") {
        setNewQuestion({
          type: value,
          statement: "",
          options: [
            { label: "A", text: "" },
            { label: "B", text: "" },
            { label: "C", text: "" },
            { label: "D", text: "" },
          ],
          answer: "",
        });
      } else if (value === "understandingArguments") {
        setNewQuestion({
          type: value,
          statement: "",
          options: [
            { text: "", type: "memperkuat" },
            { text: "", type: "memperlemah" },
          ],
          answer: "",
        });
      } else {
        setNewQuestion({
          type: value,
          statement: "",
          options: [],
          answer: "",
        });
      }
    } else if (index !== null) {
      const updatedOptions = [...newQuestion.options];
      updatedOptions[index][name] = value;
      setNewQuestion((prev) => ({ ...prev, options: updatedOptions }));
    } else {
      setNewQuestion((prev) => ({ ...prev, [name]: value }));
    }
  };

  const handleAddOption = () => {
    if (newQuestion.type === "understandingArguments") {
      setNewQuestion((prev) => ({
        ...prev,
        options: [...prev.options, { text: "", type: "memperkuat" }],
      }));
    }
  };

  const handleAddQuestion = async () => {
    const user = auth.currentUser;
    if (!user || !tutorDocId) {
      alert("User belum login");
      return;
    }

    try {
      // --- FIXED PATH ---
      const questionsRef = collection(
        db,
        "tutor",
        tutorDocId,
        "Soal",
        sesi,
        "subtest",
        subtest,
        "questions"
      );
      const questionDoc = await addDoc(questionsRef, newQuestion);
      setQuestions([...questions, { ...newQuestion, id: questionDoc.id }]);
      console.log("✅ Soal berhasil disimpan ke Firestore");
    } catch (error) {
      console.error("❌ Gagal menyimpan soal:", error);
    }

    // Reset form
    setNewQuestion({
      type: "multipleChoice",
      statement: "",
      options: [
        { label: "A", text: "" },
        { label: "B", text: "" },
        { label: "C", text: "" },
        { label: "D", text: "" },
      ],
      answer: "",
    });
  };

  return (
    <div className="admin-dashboard">
      <h2>Edit Soal - <span style={{color:'#20b46a'}}>{sesi}</span></h2>
      <h3>Subtest: <span style={{color:'#2980ef'}}>{subtest}</span></h3>
      <div className="question-form">
        <h3>Tambah Soal Baru</h3>
        <select name="type" value={newQuestion.type} onChange={handleInputChange}>
          <option value="multipleChoice">Pilihan Ganda</option>
          <option value="shortAnswer">Isian Singkat</option>
          <option value="understandingArguments">Memahami Argumen</option>
        </select>
        <textarea
          name="statement"
          placeholder="Masukkan pernyataan soal"
          value={newQuestion.statement}
          onChange={handleInputChange}
        ></textarea>
        {newQuestion.type === "multipleChoice" && (
          <>
            <div className="options">
              {newQuestion.options.map((option, index) => (
                <div key={index} className="option-row">
                  <label style={{ width: "20px", fontWeight: "bold", marginRight: "10px" }}>{option.label}.</label>
                  <input
                    type="text"
                    placeholder={`Opsi ${option.label}`}
                    name="text"
                    value={option.text}
                    onChange={(e) => handleInputChange(e, index)}
                  />
                </div>
              ))}
            </div>
            <label style={{ fontWeight: "bold", marginTop: "10px", display: "block" }}>
              Jawaban Benar (A, B, C, atau D):
            </label>
            <input
              type="text"
              maxLength={1}
              name="answer"
              placeholder="Masukkan jawaban benar"
              value={newQuestion.answer}
              onChange={handleInputChange}
              style={{ width: "200px", padding: "8px", fontSize: "1rem", marginTop: "5px" }}
            />
          </>
        )}
        {newQuestion.type === "shortAnswer" && (
          <input
            type="text"
            name="answer"
            placeholder="Masukkan jawaban"
            value={newQuestion.answer}
            onChange={handleInputChange}
            style={{ marginTop: "10px", padding: "10px", width: "100%", fontSize: "1rem" }}
          />
        )}
        {newQuestion.type === "understandingArguments" && (
          <>
            <div className="options">
              {newQuestion.options.map((option, index) => (
                <div key={index} className="option-row">
                  <input
                    type="text"
                    placeholder={`Opsi ${index + 1}`}
                    name="text"
                    value={option.text}
                    onChange={(e) => handleInputChange(e, index)}
                  />
                  <select
                    name="type"
                    value={option.type}
                    onChange={(e) => handleInputChange(e, index)}
                  >
                    <option value="memperkuat">Memperkuat</option>
                    <option value="memperlemah">Memperlemah</option>
                  </select>
                </div>
              ))}
            </div>
            <button onClick={handleAddOption}>Tambah Opsi</button>
          </>
        )}
        <button onClick={handleAddQuestion} style={{ marginTop: "15px" }}>
          Simpan Soal
        </button>
      </div>
      <div className="question-list">
        <h3>Daftar Soal ({sesi} - {subtest})</h3>
        {loading ? (
          <div>Loading...</div>
        ) : questions.length === 0 ? (
          <p>Belum ada soal.</p>
        ) : (
          questions.map((q, index) => (
            <div key={q.id} className="question-item">
              <h4>Soal {index + 1}</h4>
              <p>{q.statement}</p>
              {q.type === "multipleChoice" && (
                <>
                  <ul>
                    {q.options.map((opt, optIndex) => (
                      <li key={optIndex}>
                        <strong>{opt.label}.</strong> {opt.text}
                      </li>
                    ))}
                  </ul>
                  <p>Jawaban Benar: <strong>{q.answer}</strong></p>
                </>
              )}
              {q.type === "shortAnswer" && (
                <p>Jawaban: <strong>{q.answer}</strong></p>
              )}
              {q.type === "understandingArguments" && (
                <ul>
                  {q.options.map((opt, optIndex) => (
                    <li key={optIndex}>
                      {opt.text} - <strong>{opt.type}</strong>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default AdminDashboard;
