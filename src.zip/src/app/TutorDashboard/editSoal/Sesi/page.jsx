'use client';
import React, { useEffect, useState } from "react";
import { collection, doc, getDocs, setDoc, query, where } from "firebase/firestore";
import { db, auth } from "../../../firebase/config.js";
import { onAuthStateChanged } from "firebase/auth";
import { Plus, ListChecks } from 'lucide-react';
import "./style.css";

export default function SessionSelector() {
  const [uid, setUid] = useState("");
  const [tutorDocId, setTutorDocId] = useState("");
  const [sessions, setSessions] = useState(
    Array.from({ length: 20 }, (_, i) => `Sesi${i + 1}`)
  );
  // Tambahkan "Free" di awal!
  const [specialSession] = useState("Free");
  const [existingSessions, setExistingSessions] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (user) => {
      if (!user) {
        alert("Kamu belum login");
        window.location.href = "/auth";
        return;
      }
      setUid(user.uid);

      const q = query(collection(db, "tutor"), where("uid", "==", user.uid));
      const qs = await getDocs(q);
      if (!qs.empty) {
        const tutorDoc = qs.docs[0];
        setTutorDocId(tutorDoc.id);

        const sesiSnap = await getDocs(collection(db, "tutor", tutorDoc.id, "Soal"));
        setExistingSessions(sesiSnap.docs.map(d => d.id));
      }
      setLoading(false);
    });
    return () => unsub();
  }, []);

  // --- UBAH REDIRECT KE SUBTEST SELECTOR ---
  const handleSessionClick = async (sesiName) => {
    if (!tutorDocId) return;
    const sesiDocRef = doc(db, "tutor", tutorDocId, "Soal", sesiName);

    if (!existingSessions.includes(sesiName)) {
      await setDoc(sesiDocRef, {});
    }
    // Redirect ke halaman subtest
    window.location.href = `/TutorDashboard/editSoal/Sesi/subtest?sesi=${sesiName}`;
  };

  const handleAddSession = async () => {
    let idx = sessions.length;
    let nextSession = `Sesi${idx + 1}`;
    setSessions([...sessions, nextSession]);
    await handleSessionClick(nextSession);
  };

  if (loading) return (
    <div className="ss-center">
      <div className="ss-spinner"></div>
    </div>
  );

  return (
    <div className="ss-root">
      <div className="ss-card">
        <div className="ss-header">
          <ListChecks size={28} className="ss-icon-main" />
          <h2>Kelola Sesi Tryout</h2>
        </div>
        <p className="ss-desc">
          Pilih sesi tryout untuk mulai mengelola atau tambahkan sesi baru jika diperlukan.
        </p>
        <div className="ss-btn-list">
          {/* Button khusus Free */}
          <button
            key={specialSession}
            onClick={() => handleSessionClick(specialSession)}
            className={`ss-btn ss-btn-free ${existingSessions.includes(specialSession) ? "ss-btn-exist" : ""}`}
            aria-label={`Pilih sesi Free`}
            style={{background: "#edf6ff", color: "#1565c0", borderColor: "#90caf9", fontWeight: "bold"}}
          >
            <span>{specialSession}</span>
            {existingSessions.includes(specialSession) &&
              <span className="ss-badge">Ada</span>
            }
          </button>
          {/* Daftar sesi normal */}
          {sessions.map((sesi) => (
            <button
              key={sesi}
              onClick={() => handleSessionClick(sesi)}
              className={`ss-btn ${existingSessions.includes(sesi) ? "ss-btn-exist" : ""}`}
              aria-label={`Pilih ${sesi}`}
            >
              <span>{sesi}</span>
              {existingSessions.includes(sesi) &&
                <span className="ss-badge">Ada</span>
              }
            </button>
          ))}
          <button
            onClick={handleAddSession}
            className="ss-btn ss-btn-add"
            aria-label="Tambah sesi baru"
          >
            <Plus size={18} />
            Tambah Sesi Baru
          </button>
        </div>
        <div className="ss-label">
          <span>Sesi yang sudah ada akan muncul dengan label <span className="ss-badge">Ada</span>.</span>
        </div>
      </div>
    </div>
  );
}
