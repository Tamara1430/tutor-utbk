import React from "react";
import { FaCheck } from "react-icons/fa";

export default function Testing() {
  return (
    <section id="testing" className="utbk-testing-bg">
      <div className="utbk-testing-container">
        <div className="utbk-testing-header">
          <h2 className="utbk-testing-title">Testing Platform</h2>
          <p className="utbk-testing-sub">
            Coba fitur-fitur unggulan platform kami sebelum bergabung
          </p>
        </div>
        <div className="utbk-testing-content">
          <div className="utbk-testing-features">
            <div className="utbk-testing-feature">
              <div className="utbk-testing-icon"><FaCheck /></div>
              <div>
                <div className="utbk-testing-feature-title">Website Builder</div>
                <div className="utbk-testing-feature-desc">
                  Buat website UTBK yang menarik dengan drag-and-drop builder yang mudah digunakan
                </div>
              </div>
            </div>
            <div className="utbk-testing-feature">
              <div className="utbk-testing-icon"><FaCheck /></div>
              <div>
                <div className="utbk-testing-feature-title">Analytics Dashboard</div>
                <div className="utbk-testing-feature-desc">
                  Monitor performa website dan track progress siswa dengan dashboard yang komprehensif
                </div>
              </div>
            </div>
            <div className="utbk-testing-feature">
              <div className="utbk-testing-icon"><FaCheck /></div>
              <div>
                <div className="utbk-testing-feature-title">Payment Integration</div>
                <div className="utbk-testing-feature-desc">
                  Sistem pembayaran terintegrasi dengan berbagai metode pembayaran populer
                </div>
              </div>
            </div>
            <div className="utbk-testing-demo-btn-wrap">
              <button
                className="utbk-testing-demo-btn"
                onClick={() => alert('Demo akan dimulai! Anda akan diarahkan ke platform demo kami.')}
              >
                Mulai Demo Gratis
              </button>
            </div>
          </div>
          <div className="utbk-testing-dashboard-wrap">
            <div className="utbk-testing-dashboard">
              <div className="utbk-testing-dashboard-head">
                <div className="utbk-testing-dashboard-title">Demo Dashboard</div>
                <div className="utbk-testing-dashboard-traffic">
                  <div className="utbk-dot utbk-dot-red"></div>
                  <div className="utbk-dot utbk-dot-yellow"></div>
                  <div className="utbk-dot utbk-dot-green"></div>
                </div>
              </div>
              <div className="utbk-testing-dashboard-body">
                <div className="utbk-dashboard-metrics">
                  <div className="utbk-dashboard-metric utbk-metric-siswa">
                    <div className="utbk-metric-value">1,234</div>
                    <div className="utbk-metric-label">Total Siswa</div>
                  </div>
                  <div className="utbk-dashboard-metric utbk-metric-income">
                    <div className="utbk-metric-value">Rp 45M</div>
                    <div className="utbk-metric-label">Pendapatan</div>
                  </div>
                </div>
                <div className="utbk-dashboard-progress-wrap">
                  <div className="utbk-dashboard-progress-label">
                    <span>Website Views</span>
                    <span>85%</span>
                  </div>
                  <div className="utbk-dashboard-progress-bar">
                    <div className="utbk-dashboard-progress-fill"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <style jsx>{`
        .utbk-testing-bg {
          background: #f8fafc;
          padding: 90px 0;
        }
        .utbk-testing-container {
          max-width: 1200px;
          margin: 0 auto;
          padding: 0 2rem;
        }
        .utbk-testing-header {
          text-align: center;
          margin-bottom: 3.2rem;
        }
        .utbk-testing-title {
          font-family: 'Inter', sans-serif;
          font-size: 2.5rem;
          font-weight: 700;
          color: #222;
          margin-bottom: 1.1rem;
        }
        .utbk-testing-sub {
          font-size: 1.14rem;
          color: #4b5563;
          max-width: 540px;
          margin: 0 auto;
        }
        .utbk-testing-content {
          display: grid;
          grid-template-columns: 1.3fr 1fr;
          gap: 3rem;
          align-items: center;
        }
        .utbk-testing-features {
          display: flex;
          flex-direction: column;
          gap: 1.9rem;
        }
        .utbk-testing-feature {
          display: flex;
          gap: 1.3rem;
          align-items: flex-start;
        }
        .utbk-testing-icon {
          width: 2.2rem;
          height: 2.2rem;
          background: #2563eb;
          color: #fff;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 1.14rem;
          margin-top: 0.2rem;
          flex-shrink: 0;
        }
        .utbk-testing-feature-title {
          font-size: 1.13rem;
          font-weight: 700;
          color: #1e293b;
          margin-bottom: 0.32rem;
        }
        .utbk-testing-feature-desc {
          color: #64748b;
          font-size: 0.99rem;
        }
        .utbk-testing-demo-btn-wrap {
          margin-top: 2.3rem;
        }
        .utbk-testing-demo-btn {
          background: #2563eb;
          color: #fff;
          font-weight: 700;
          font-family: 'Inter', sans-serif;
          font-size: 1.1rem;
          padding: 1rem 2.2rem;
          border: none;
          border-radius: 0.8rem;
          cursor: pointer;
          box-shadow: 0 2px 18px 0 rgba(60,100,255,0.09);
          transition: background 0.18s;
        }
        .utbk-testing-demo-btn:hover {
          background: #1e40af;
        }
        .utbk-testing-dashboard-wrap {
          display: flex;
          justify-content: center;
        }
        .utbk-testing-dashboard {
          background: #fff;
          border-radius: 1.4rem;
          box-shadow: 0 8px 28px 0 rgba(60,100,255,0.07);
          padding: 2.4rem 2rem;
          width: 100%;
          max-width: 380px;
          min-width: 300px;
        }
        .utbk-testing-dashboard-head {
          display: flex;
          align-items: center;
          justify-content: space-between;
        }
        .utbk-testing-dashboard-title {
          font-weight: 700;
          color: #222;
          font-size: 1.2rem;
        }
        .utbk-testing-dashboard-traffic {
          display: flex;
          gap: 0.42rem;
        }
        .utbk-dot {
          width: 0.8rem; height: 0.8rem;
          border-radius: 9999px;
        }
        .utbk-dot-red { background: #f87171; }
        .utbk-dot-yellow { background: #fbbf24; }
        .utbk-dot-green { background: #34d399; }
        .utbk-testing-dashboard-body {
          margin-top: 1.5rem;
        }
        .utbk-dashboard-metrics {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 1.1rem;
          margin-bottom: 1.3rem;
        }
        .utbk-dashboard-metric {
          background: #eff6ff;
          padding: 1rem 1.1rem;
          border-radius: 0.8rem;
        }
        .utbk-metric-siswa .utbk-metric-value { color: #2563eb;}
        .utbk-metric-income .utbk-metric-value { color: #22c55e;}
        .utbk-metric-value {
          font-size: 1.6rem;
          font-weight: 700;
          margin-bottom: 0.3rem;
        }
        .utbk-metric-label {
          color: #64748b;
          font-size: 0.98rem;
        }
        .utbk-dashboard-progress-wrap {
          margin-top: 0.8rem;
        }
        .utbk-dashboard-progress-label {
          display: flex;
          justify-content: space-between;
          font-size: 0.98rem;
          color: #222;
          margin-bottom: 0.3rem;
        }
        .utbk-dashboard-progress-bar {
          background: #e5e7eb;
          border-radius: 999px;
          height: 9px;
          width: 100%;
          position: relative;
          overflow: hidden;
        }
        .utbk-dashboard-progress-fill {
          background: #2563eb;
          width: 85%;
          height: 100%;
          border-radius: 999px;
        }
        @media (max-width: 900px) {
          .utbk-testing-content {
            grid-template-columns: 1fr;
            gap: 2.6rem;
          }
          .utbk-testing-dashboard-wrap { margin-top: 2.3rem;}
        }
      `}</style>
    </section>
  );
}
