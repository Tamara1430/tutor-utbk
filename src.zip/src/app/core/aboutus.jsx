import React from "react";
import { FaGlobe, FaDollarSign, FaChartBar, FaCog } from "react-icons/fa";

export default function AboutUs() {
  return (
    <section className="utbk-aboutus-bg">
      <div className="utbk-aboutus-container">
        {/* Badge */}
        <div className="utbk-aboutus-badge">About Us</div>
        {/* Judul */}
        <h2 className="utbk-aboutus-title">
          Platform <span className="utbk-aboutus-highlight">Terdepan</span> untuk Tutor UTBK
        </h2>
        {/* Subjudul */}
        <p className="utbk-aboutus-desc">
          Kami adalah platform yang menghubungkan tutor berpengalaman dengan siswa yang membutuhkan bimbingan UTBK.
          Dengan teknologi terdepan, kami memungkinkan tutor untuk memiliki website kostumisasi dan mengelola siswa dengan mudah.
        </p>
        {/* Card Grid */}
        <div className="utbk-aboutus-features">
          <div className="utbk-aboutus-feature-card">
            <div className="utbk-aboutus-feature-icon"><FaGlobe /></div>
            <div className="utbk-aboutus-feature-title">Website Kostumisasi</div>
            <div className="utbk-aboutus-feature-desc">
              Buat website UTBK sesuai gaya mengajarmu dengan template yang dapat disesuaikan.
            </div>
          </div>
          <div className="utbk-aboutus-feature-card">
            <div className="utbk-aboutus-feature-icon"><FaDollarSign /></div>
            <div className="utbk-aboutus-feature-title">Komisi Kompetitif</div>
            <div className="utbk-aboutus-feature-desc">
              Dapatkan komisi 5-10% dari setiap siswa yang bergabung melalui website kamu.
            </div>
          </div>
          <div className="utbk-aboutus-feature-card">
            <div className="utbk-aboutus-feature-icon"><FaChartBar /></div>
            <div className="utbk-aboutus-feature-title">Analytics Lengkap</div>
            <div className="utbk-aboutus-feature-desc">
              Pantau performa mengajar dan pendapatan dengan dashboard analytics yang detail.
            </div>
          </div>
          <div className="utbk-aboutus-feature-card">
            <div className="utbk-aboutus-feature-icon"><FaCog /></div>
            <div className="utbk-aboutus-feature-title">Tools Lengkap</div>
            <div className="utbk-aboutus-feature-desc">
              Akses ke berbagai tools mengajar, manajemen siswa, dan sistem pembayaran.
            </div>
          </div>
        </div>
      </div>
      <style jsx>{`
        .utbk-aboutus-bg {
          background: #f7f9fb;
          padding: 82px 0 60px 0;
        }
        .utbk-aboutus-container {
          max-width: 1250px;
          margin: 0 auto;
          padding: 0 2rem;
          text-align: center;
        }
        .utbk-aboutus-badge {
          display: inline-block;
          padding: 5px 20px;
          background: #e3edff;
          color: #2563eb;
          font-weight: 600;
          font-size: 1rem;
          border-radius: 1.2rem;
          margin-bottom: 18px;
        }
        .utbk-aboutus-title {
          font-family: 'Inter', sans-serif;
          font-size: 2.9rem;
          font-weight: 700;
          color: #151e2d;
          margin-bottom: 18px;
        }
        .utbk-aboutus-highlight {
          color: #2563eb;
        }
        .utbk-aboutus-desc {
          max-width: 940px;
          margin: 0 auto 42px auto;
          color: #434957;
          font-size: 1.25rem;
          line-height: 1.55;
        }
        .utbk-aboutus-features {
          margin: 0 auto;
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 2.3rem;
        }
        .utbk-aboutus-feature-card {
          background: #fff;
          border-radius: 1.25rem;
          box-shadow: 0 6px 32px 0 rgba(100,130,255,0.09);
          padding: 2.6rem 1.3rem 2rem 1.3rem;
          text-align: center;
          transition: transform 0.16s, box-shadow 0.18s;
          display: flex;
          flex-direction: column;
          align-items: center;
        }
        .utbk-aboutus-feature-card:hover {
          transform: translateY(-8px) scale(1.03);
          box-shadow: 0 10px 32px 0 rgba(100,130,255,0.17);
        }
        .utbk-aboutus-feature-icon {
          width: 56px;
          height: 56px;
          border-radius: 16px;
          background: #e3edff;
          color: #2563eb;
          font-size: 2rem;
          display: flex;
          align-items: center;
          justify-content: center;
          margin-bottom: 1.1rem;
        }
        .utbk-aboutus-feature-title {
          font-size: 1.27rem;
          font-weight: 700;
          color: #111928;
          margin-bottom: 0.6rem;
        }
        .utbk-aboutus-feature-desc {
          font-size: 1.04rem;
          color: #4b5563;
        }
        @media (max-width: 1100px) {
          .utbk-aboutus-features {
            grid-template-columns: 1fr 1fr;
            gap: 1.4rem;
          }
        }
        @media (max-width: 700px) {
          .utbk-aboutus-features {
            grid-template-columns: 1fr;
            gap: 1rem;
          }
          .utbk-aboutus-title { font-size: 2.1rem;}
          .utbk-aboutus-container { padding: 0 1rem;}
        }
      `}</style>
    </section>
  );
}
